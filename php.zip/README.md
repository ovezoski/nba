+Working features: 
 +  Create a team (name only)
 +  add players in the team
 +  edit the players
 +  delete the players
 +  add youtube videos to players